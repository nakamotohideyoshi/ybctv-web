<?php

echo '<div id="root"></div>';
?>