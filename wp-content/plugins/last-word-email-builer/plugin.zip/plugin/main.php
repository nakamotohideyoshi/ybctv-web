<?php
/*
Plugin Name: Email Builder
Plugin URI: http://codebasehq.com
Description: This is an email builder plugin.
Author: Simon Smith
Version: 0.1
Author URI: http://codebasehq.com
Network: True
*/
class EmailBuilder {
	public $plugin_domain;
	public $views_dir;
	public $version;

	public function __construct() {
		$this->plugin_domain = 'email-builder';
		$this->views_dir     = trailingslashit( dirname( __FILE__ ) ) . 'server/views';
		$this->version       = '1.0';
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'rest_api_init', array( $this, 'wpshout_register_routes' ) );
	}
	
	public function wpshout_register_routes() {
    register_rest_route( 
        'email-builder/v1',
        '/posts',
        array(
            'methods' => 'GET',
            'callback' => function ($params ){
				$args = array(
					'posts_per_page' => 10,
					'paged'=>$params['page']
				);

			    $my_query = new WP_Query( $args );   
			    foreach($my_query->posts as $row){ 
					$image = wp_get_attachment_image_src(get_post_thumbnail_id($row->ID),"full");
					$row->featured_image = $image[0];
				}				
			    return (object)array($my_query->posts, $my_query->found_posts);
			  }
        )
     );
	 register_rest_route( 
        'email-builder/v1',
        '/images',
        array(
            'methods' => 'GET',
            'callback' => function ($params ){
				$query_images_args = array(
					'post_type'      => 'attachment',
					'post_mime_type' => 'image',
					'post_status'    => 'inherit',
					'posts_per_page' => - 1,
				);

				$query_images = new WP_Query( $query_images_args );

				$images = array();
				foreach ( $query_images->posts as $image ) {
					$images[] = wp_get_attachment_url( $image->ID );
				}			
			    return $images;
			  }
        )
     );
	 register_rest_route( 
        'email-builder/v1',
        '/emails',
        array(
            'methods' => 'GET',
            'callback' => function ($params ){
				global $wpdb;
				$table_name = $wpdb->prefix . 'email_builder_emails';
				$no_rows = $wpdb->get_results("SELECT count(*) as count FROM ".$table_name."");
				$emails = $wpdb->get_results("SELECT * FROM ".$table_name." ORDER BY EmailId DESC  LIMIT 5 OFFSET ".$params['offset']."");
				if ($wpdb->last_error) {
  					$response = new WP_REST_Response( $wpdb->last_error );
					return $response;
				}				
			    return (object)array($emails, $no_rows[0]->count);
			  }
        )
     );
	 register_rest_route( 
        'email-builder/v1',
        '/static',
        array(
            'methods' => 'GET',
            'callback' => function ($params ){
				global $wpdb;
				$table_name = $wpdb->prefix . 'email_builder_static';
				$static = $wpdb->get_results("SELECT * FROM ".$table_name." WHERE Type = '". $params['type'] ."' AND Template = '". $params['template'] ."'");
				if ($wpdb->last_error) {
  					$response = new WP_REST_Response( $wpdb->last_error );
					return $response;
				}				
			    return $static[0];
			  }
        )
     );
	 register_rest_route( 
        'email-builder/v1',
        '/statictemplate',
        array(
            'methods' => 'GET',
            'callback' => function ($params ){
				global $wpdb;
				$table_name = $wpdb->prefix . 'email_builder_static';
				$static = $wpdb->get_results("SELECT * FROM ".$table_name." WHERE Template = '". $params['template'] ."'");
				if ($wpdb->last_error) {
  					$response = new WP_REST_Response( $wpdb->last_error );
					return $response;
				}				
			    return $static;
			  }
        )
     );
	 register_rest_route( 
        'email-builder/v1',
        '/email',
        array(
            'methods' => 'GET',
            'callback' => function ($params ){
				global $wpdb;
				$table_name = $wpdb->prefix . 'email_builder_emails';
				$email = $wpdb->get_results("SELECT * FROM ".$table_name." WHERE EmailId = ".$params['emailId']."");
				if ($wpdb->last_error) {
  					$response = new WP_REST_Response( $wpdb->last_error );
					return $response;
				}				
			    return $email[0];
			  }
        )
     );
	 register_rest_route( 
        'email-builder/v1',
        '/static',
        array(
            'methods' => 'POST',
            'callback' => function ($data ){
				$json_result = json_decode($data->get_body(), true);
				$type = $json_result["type"];
				$template = $json_result["template"];
				$content = $json_result["content"];
				
				global $wpdb;
				$table_name = $wpdb->prefix . 'email_builder_static';
				$result = $wpdb->get_results("SELECT * FROM ".$table_name." WHERE Type = '".$type."' and Template = '".$template."'");


				if($wpdb->num_rows > 0) {
					$wpdb->update( 
						$table_name, 
						array( 
							'Content' => $content
						),
						array(
							'Type' => $type, 
							'Template' => $template,
						)
					 );
				 return $result[0]->ContentId;
				}
				
				$wpdb->insert( 
					$table_name, 
					array( 
						'Type' => $type, 
						'Template' => $template,
						'Content' => $content
					) 
				);
				
				if ($wpdb->last_error) {
  					$response = new WP_REST_Response( $wpdb->last_error );
					return $response;
				}
				
				return $wpdb->insert_id;
			  }
        )
     );
	 register_rest_route( 
        'email-builder/v1',
        '/emails',
        array(
            'methods' => 'POST',
            'callback' => function ($data ){
				$json_result = json_decode($data->get_body(), true);
				$email_name = $json_result["name"];
				$email_articles = $json_result["articles"];
				$template_name = $json_result["template"];
				
				global $wpdb;
				$table_name = $wpdb->prefix . 'email_builder_emails';
				$wpdb->get_results("SELECT * FROM ".$table_name." WHERE EmailName = '".$email_name."'");
				if ($wpdb->last_error) {
  					$response = new WP_REST_Response( $wpdb->last_error );
					return $response;
				}
				if($wpdb->num_rows > 0) {
					 $error = new WP_Error;
					 $error->add( "500", "Email with same name already exists." );
					 return $error;
				}
				
				$wpdb->insert( 
					$table_name, 
					array( 
						'EmailName' => $email_name, 
						'Articles' => $email_articles,
						'TemplateName' => $template_name
					) 
				);
				
                $response = new WP_REST_Response( $json_result["name"] );
				return $wpdb->insert_id;
			  }
        )
     );
   }

	
	public function admin_menu() {
		$title = __( 'Email Builder', $this->plugin_domain );
		$hook_suffix = add_management_page( $title, $title, 'export', $this->plugin_domain, array(
			$this,
			'load_admin_view',
		) );
		add_action( 'load-' . $hook_suffix, array( $this, 'load_bundle' ) );

	}
	public function load_view( $view ) {
		$path = trailingslashit( $this->views_dir ) . $view;
		if ( file_exists( $path ) ) {
			include $path;
		}
	}
	public function load_admin_view() {
		$this->load_view( 'admin.php' );
			
	}
	public function load_bundle() {
		wp_register_script( 'jQuery', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js', null, null, true );
        wp_enqueue_script('jQuery');
		wp_enqueue_style( 'prefix-style', plugins_url('css\main.25990e6a.css', __FILE__) );
        wp_enqueue_script( 'plugin-scripts', plugins_url('js/main.339e9762.js', __FILE__),array(),  '0.0.1', true );

	}
	
    public function jal_install() {
		
		global $wpdb;

		$table_name = $wpdb->prefix . 'email_builder_emails';
		
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name (
			EmailId mediumint(9) NOT NULL AUTO_INCREMENT,
			EmailName VARCHAR(1000) NULL,
			Articles VARCHAR(1000) NULL,
			TemplateName VARCHAR(1000) NULL,
			SendToAdestraOn varchar(1000) NULL,
			PRIMARY KEY  (EmailId)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
		
		$static_table_name = $wpdb->prefix . 'email_builder_static';
		
		$static_sql = "CREATE TABLE $static_table_name (
		  ContentId INT NOT NULL AUTO_INCREMENT,
		  Type VARCHAR(1000) NULL,
		  Template VARCHAR(1000) NULL,
		  Content TEXT NULL,
		  PRIMARY KEY (ContentId))$charset_collate;";
		  
		dbDelta( $static_sql );

		add_option( 'jal_db_version', '1.0' );
    }

    public function jal_install_data() {
		global $wpdb;
		
		$welcome_name = 'Mr. WordPress';
		$welcome_text = 'Congratulations, you just completed the installation!';
		
		$table_name = $wpdb->prefix . 'email_builder';
		
		$wpdb->insert( 
			$table_name, 
			array( 
				'time' => current_time( 'mysql' ), 
				'name' => $welcome_name, 
				'text' => $welcome_text, 
			) 
		);
	}
}

register_activation_hook( __FILE__, array(EmailBuilder, 'jal_install') );
register_activation_hook( __FILE__, array(EmailBuilder, 'jal_install_data') );
new EmailBuilder();
?>